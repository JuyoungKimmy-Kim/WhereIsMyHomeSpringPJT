<template>
<section class="pt-8 pb-7">
    <div class="container">
    <div class="row">
        <div class="col-lg-4 col-md-6">
        <div class="card">
            <div class="card-header p-0 mx-3 mt-n4 position-relative z-index-2">
            <a class="d-block blur-shadow-image">
                <img src="@/assets/img/bg.jpg" alt="img-blur-shadow" class="img-fluid border-radius-lg">
            </a>
            </div>
            <div class="card-body pt-3">
            <p class="text-dark mb-2 text-sm">Entire Apartment • 3 Guests • 2 Beds</p>
            <a href="javascript:;">
                <h5>
                Lovely and cosy apartment
                </h5>
            </a>
            <p>
                Siri&#39;s latest trick is offering a hands-free TV viewing experience, that will allow consumers to turn on or off their television, change inputs, fast forward.
            </p>
            </div>
        </div>
        </div>
        <div class="col-lg-4 col-md-6">
        <div class="card">
            <div class="card-header p-0 mx-3 mt-n4 position-relative z-index-2">
            <a class="d-block blur-shadow-image">
                <img src="@/assets/img/bg.jpg" alt="img-blur-shadow" class="img-fluid border-radius-lg">
            </a>
            </div>
            <div class="card-body pt-3">
            <p class="text-dark mb-2 text-sm">Private Room • 1 Guests • 1 Sofa</p>
            <a href="javascript:;">
                <h5>
                Single room in the center of the city
                </h5>
            </a>
            <p>
                As Uber works through a huge amount of internal management turmoil, the company is also consolidating more of its international business.
            </p>
            </div>
        </div>
        </div>
        <div class="col-lg-4 col-md-6">
        <div class="card">
            <div class="card-header p-0 mx-3 mt-n4 position-relative z-index-2">
            <a class="d-block blur-shadow-image">
                <img src="@/assets/img/bg.jpg" alt="img-blur-shadow" class="img-fluid border-radius-lg">
            </a>
            </div>
            <div class="card-body pt-3">
            <p class="text-dark mb-2 text-sm">Entire Apartment • 4 Guests • 2 Beds</p>
            <a href="javascript:;">
                <h5>
                Independent house bedroom kitchen
                </h5>
            </a>
            <p>
                Music is something that every person has his or her own specific opinion about. Different people have different taste, and various types of music.
            </p>
            </div>
        </div>
        </div>
    </div>
    </div>
</section>
</template>

<script>
export default {

}
</script>

<style>

</style>