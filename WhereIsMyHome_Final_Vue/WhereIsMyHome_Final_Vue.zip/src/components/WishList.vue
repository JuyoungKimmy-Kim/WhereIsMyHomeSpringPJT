<template>
<div>
    <header-page></header-page>

    <div class="card card-body sticky blur shadow-blur mx-3 mx-md-6 mt-n6">
        <section>
        <div class="container">
            <h4 class="row justify-content-center">찜목록 관리</h4>
            <div class="row justify-content-center pb-5">
            <div class="col-lg-11">
                <div class="card">
                <div class="table-responsive" style="overflow-x: hidden">
                    <table class="table align-items-center mb-0">
                    <thead>
                        <tr>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">매물</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">가격</th>
                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">지도에서 확인하기</th>
                        <th class="text-secondary text-xxs opacity-7">목록에서 삭제</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <td>
                            <div class="d-flex px-2 py-1">
                            <div>
                                <img src="@/assets/img/apt/송정삼정그린코아더시티.jpg" class="avatar avatar-sm me-3">
                            </div>
                            <div class="d-flex flex-column justify-content-center">
                                <h6 class="mb-0 text-xs">부산광역시 강서구 송정동</h6>
                                <p class="text-xs text-secondary mb-0">송정삼정그린코아 더시티 오피스텔</p>
                            </div>
                            </div>
                        </td>
                        <td>
                            <p class="text-xs font-weight-bold mb-0">단위 (만원)</p>
                            <p class="text-xs text-secondary mb-0">6,000</p>
                        </td>
                        <td class="align-middle text-center">
                            <!--<span class="text-secondary text-xs font-weight-bold">23/04/18</span>-->
                            <i class="material-icons opacity-6 me-2 text-md"> <router-link to="/map">
                                    arrow_forward</router-link></i>
                        </td>
                        <td class="align-middle">
                            <i class="material-icons opacity-6 me-2 text-md">close</i>
                        </td>
                        </tr>
                        <tr>
                        <td>
                            <div class="d-flex px-2 py-1">
                            <div>
                                <img src="@/assets/img/apt/송정삼정그린코아더시티.jpg" class="avatar avatar-sm me-3">
                            </div>
                            <div class="d-flex flex-column justify-content-center">
                                <h6 class="mb-0 text-xs">부산광역시 강서구 송정동</h6>
                                <p class="text-xs text-secondary mb-0">송정삼정그린코아 더시티 오피스텔</p>
                            </div>
                            </div>
                        </td>
                        <td>
                            <p class="text-xs font-weight-bold mb-0">단위 (만원)</p>
                            <p class="text-xs text-secondary mb-0">6,000</p>
                        </td>
                        <td class="align-middle text-center">
                            <!--<span class="text-secondary text-xs font-weight-bold">23/04/18</span>-->
                            <i class="material-icons opacity-6 me-2 text-md"> <router-link to="/map">
                                    arrow_forward</router-link></i>
                        </td>
                        <td class="align-middle">
                            <i class="material-icons opacity-6 me-2 text-md">close</i>
                        </td>
                        </tr>
                                                <tr>
                        <td>
                            <div class="d-flex px-2 py-1">
                            <div>
                                <img src="@/assets/img/apt/송정삼정그린코아더시티.jpg" class="avatar avatar-sm me-3">
                            </div>
                            <div class="d-flex flex-column justify-content-center">
                                <h6 class="mb-0 text-xs">부산광역시 강서구 송정동</h6>
                                <p class="text-xs text-secondary mb-0">송정삼정그린코아 더시티 오피스텔</p>
                            </div>
                            </div>
                        </td>
                        <td>
                            <p class="text-xs font-weight-bold mb-0">단위 (만원)</p>
                            <p class="text-xs text-secondary mb-0">6,000</p>
                        </td>
                        <td class="align-middle text-center">
                            <!--<span class="text-secondary text-xs font-weight-bold">23/04/18</span>-->
                            <i class="material-icons opacity-6 me-2 text-md"> <router-link to="/map">
                                    arrow_forward</router-link></i>
                        </td>
                        <td class="align-middle">
                            <i class="material-icons opacity-6 me-2 text-md">close</i>
                        </td>
                        </tr>
                                                <tr>
                        <td>
                            <div class="d-flex px-2 py-1">
                            <div>
                                <img src="@/assets/img/apt/송정삼정그린코아더시티.jpg" class="avatar avatar-sm me-3">
                            </div>
                            <div class="d-flex flex-column justify-content-center">
                                <h6 class="mb-0 text-xs">부산광역시 강서구 송정동</h6>
                                <p class="text-xs text-secondary mb-0">송정삼정그린코아 더시티 오피스텔</p>
                            </div>
                            </div>
                        </td>
                        <td>
                            <p class="text-xs font-weight-bold mb-0">단위 (만원)</p>
                            <p class="text-xs text-secondary mb-0">6,000</p>
                        </td>
                        <td class="align-middle text-center">
                            <!--<span class="text-secondary text-xs font-weight-bold">23/04/18</span>-->
                            <i class="material-icons opacity-6 me-2 text-md"> <router-link to="/map">
                                    arrow_forward</router-link></i>
                        </td>
                        <td class="align-middle">
                            <i class="material-icons opacity-6 me-2 text-md">close</i>
                        </td>
                        </tr>
                                                <tr>
                        <td>
                            <div class="d-flex px-2 py-1">
                            <div>
                                <img src="@/assets/img/apt/송정삼정그린코아더시티.jpg" class="avatar avatar-sm me-3">
                            </div>
                            <div class="d-flex flex-column justify-content-center">
                                <h6 class="mb-0 text-xs">부산광역시 강서구 송정동</h6>
                                <p class="text-xs text-secondary mb-0">송정삼정그린코아 더시티 오피스텔</p>
                            </div>
                            </div>
                        </td>
                        <td>
                            <p class="text-xs font-weight-bold mb-0">단위 (만원)</p>
                            <p class="text-xs text-secondary mb-0">6,000</p>
                        </td>
                        <td class="align-middle text-center">
                            <!--<span class="text-secondary text-xs font-weight-bold">23/04/18</span>-->
                            <i class="material-icons opacity-6 me-2 text-md"> <router-link to="/map">
                                    arrow_forward</router-link></i>
                        </td>
                        <td class="align-middle">
                            <i class="material-icons opacity-6 me-2 text-md">close</i>
                        </td>
                        </tr>

                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>
    </section>
    </div>
</div>
</template>

<script>
import HeaderPage from '@/components/HeaderPage.vue'
export default {
    components:{
        HeaderPage
    }
}
</script>

<style>
</style>