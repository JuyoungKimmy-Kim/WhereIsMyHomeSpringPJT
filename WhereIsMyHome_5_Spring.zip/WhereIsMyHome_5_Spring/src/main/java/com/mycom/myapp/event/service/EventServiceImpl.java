package com.mycom.myapp.event.service;

import java.util.List;

import com.mycom.myapp.event.dto.EventDto;

public class EventServiceImpl implements EventService {

	@Override
	public int registerEvent(EventDto eventDto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<EventDto> getEventList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateEvent(EventDto eventDto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteEvent(int key) {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
