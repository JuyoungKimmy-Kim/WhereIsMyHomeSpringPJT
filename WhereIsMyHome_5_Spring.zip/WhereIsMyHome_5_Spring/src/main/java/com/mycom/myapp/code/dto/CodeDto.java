package com.mycom.myapp.code.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class CodeDto {
	private String groupCode;
	private String code;
	private String codeName;

}
