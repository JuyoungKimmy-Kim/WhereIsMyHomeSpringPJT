package com.mycom.myapp.code.service;

import java.util.List;

import com.mycom.myapp.code.dto.SidoDto;

public interface SidoService {
	List<SidoDto> sidoList();

}
