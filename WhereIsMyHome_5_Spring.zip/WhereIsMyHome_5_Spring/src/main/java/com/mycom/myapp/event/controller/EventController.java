package com.mycom.myapp.event.controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/event/*")
public class EventController extends HttpServlet {

	
}
