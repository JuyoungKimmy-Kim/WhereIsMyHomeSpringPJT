package com.mycom.myapp.user.controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/user/*")
public class UserController extends HttpServlet {
}