package com.mycom.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhereIsMyHome5SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhereIsMyHome5SpringApplication.class, args);
	}

}
