package com.mycom.myapp.user.service;

import com.mycom.myapp.user.dto.UserDto;

public class UserServiceImpl implements UserService{

	@Override
	public int userRegister(UserDto userDto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public UserDto login(String userEmail, String userPassword) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int userUpdate(UserDto userDto, int userSeq) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int userDelete(int userSeq) {
		// TODO Auto-generated method stub
		return 0;
	}




}
