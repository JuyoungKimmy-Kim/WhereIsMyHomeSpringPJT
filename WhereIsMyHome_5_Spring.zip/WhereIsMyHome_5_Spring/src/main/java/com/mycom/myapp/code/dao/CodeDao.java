package com.mycom.myapp.code.dao;

public interface CodeDao {
	
}
