package com.mycom.myapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhereIsMyHome5SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
